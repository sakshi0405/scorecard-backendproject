
const express=require('express');
var app=express();
const fs=require('fs');
const bodyParser=require('body-parser');
app.use(express.static('public'));


app.use(bodyParser.urlencoded({extended:true}));

app.get('/score',function(request,response){
response.sendFile(__dirname+'/score.html');

})
/*var f=require('fs')
f.unlink("data.txt",function(err,data){
    if(err) throw err;
    console.log('file deleted!');
});*/
app.post('/form-submit',function(request,response){
    var ids=request.body.id;
    var fnamee=request.body.fname;
   var email=request.body.email;
    var addr =request.body.add;
    var English=Number(request.body.eng);
    var Hindi=Number(request.body.hindi);
    var Maths=Number(request.body.maths);
    var Physics=Number(request.body.phy);
    var Chemistry=Number(request.body.che);

    var total=Number(English+Hindi+Maths+Physics+Chemistry);
    var average=total/5;
   var grade='A';
    if(average>=90){
        grade='A';
    }else if(average>=80 && average<90){
        grade='B';
    }else if(average>=70 && average<80){
        grade='C';
    }else if(average>=55 && average<70){
        grade='D';
    }else if(average>=40 && average<55){
        grade='E';
    }else {
        grade='F';
    }

    

    let scoreCard = {
        'Student Id' : ids,
        'Student Name' : fnamee,
        'email':email,
        'Address':addr,
        'English' : English,
        'Hindi' : Hindi,
        'Maths' : Maths,
        'Physics':Physics,
        'Chemistry':Chemistry,
        'Total Marks' : total,
        'Average Marks' : average,
        'Grade':grade
    }

    
    
    fs.appendFileSync("data.txt",JSON.stringify(scoreCard));
    const data = fs.readFileSync("data.txt","utf-8")
   
    console.log(data);
    response.send(data);
})

app.listen(3012,()=>{
    console.log("Server started at port:")
})